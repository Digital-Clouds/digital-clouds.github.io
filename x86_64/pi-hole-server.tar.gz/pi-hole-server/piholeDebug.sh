#!/usr/bin/sh
echo -e "Pi-hole debug options are \e[1;31mdisabled\e[0m.\n"
echo -e "ArchLinux distribution of Pi-hole is not supported by official project and this debug report CAN NOT be uploaded to their debug team."
echo -e "Follow instructions carefully on the project wiki page (\e[1;36mhttps://wiki.archlinux.org/index.php/Pi-hole\e[0m) and please refer to AUR package web page for support and debugging (\e[1;36mhttps://aur.archlinux.org/packages/pi-hole-server\e[0m).\n"
